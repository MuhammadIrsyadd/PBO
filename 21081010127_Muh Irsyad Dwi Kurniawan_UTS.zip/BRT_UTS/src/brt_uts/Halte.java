/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package brt_uts;

/**
 *
 * @author ASUS-TUF
 */
public class Halte {
     private String point;
    Halte(String point) {
    this.point = point;
    }

    public String getPoint() {
    return point;
    }  
}
