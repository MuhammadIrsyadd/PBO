/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pertemuan1;

/**
 *
 * @author ASUS-TUF
 */
import java.util.Scanner;
public class Pertemuan1 {

    public static void main(String[] args) {
         Scanner input = new Scanner(System.in);

        System.out.print("Masukkan Nama Anda : ");
        String nama = input.nextLine();

        System.out.print("Masukkan Alamat Anda : ");
        String alamat = input.nextLine();

        System.out.print("Pilih Pengalaman Anda (Pemula/Menengah/Expert): ");
        String pengalaman = input.nextLine();

        System.out.print("Apa Skill Anda (Web/Mobile/Desktop): ");
        String skill = input.nextLine();

        System.out.print("Pilih Departemen Yang Diinginkan (IT/HRD/Finance): ");
        String departemen = input.nextLine();

        int gaji =0;

        switch (departemen) {
            case "IT" -> gaji = 8000000;
            case "HRD" -> gaji = 5000000;
            case "Finance" -> gaji = 4000000;
            default -> {
                System.out.println("Departemen tidak valid");
                System.exit(0);
            }
        }

        switch (pengalaman) {
            case "Pemula" -> gaji += 500000;
            case "Menengah" -> gaji += 1000000;
            case "Expert" -> gaji += 2000000;
            default -> {
                System.out.println("Pengalaman tidak valid");
                System.exit(0);
            }
        }

        switch (skill) {
            case "Web" -> gaji += 1000000;
            case "Mobile" -> gaji += 2000000;
            case "Desktop" -> gaji += 2500000;
            default -> {
                System.out.println("Skill tidak valid");
                System.exit(0);
            }
        }

        System.out.println("Nama: " + nama);
        System.out.println("Alamat: " + alamat);
        System.out.println("Gaji: " + gaji);
    }
    
}